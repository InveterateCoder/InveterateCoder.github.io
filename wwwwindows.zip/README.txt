Include wwwwindows.js along with jQuerry.

creating windows:

<div class="window">
	<div class="client" data-top="" data-left="" data-width="" data-height=""> <!-- iframe can be used -->
	</div>
</div>

data attributes are optional, defaults will be used if ommited.

default position: data-top="50" data-left="50"
default size: data-width="600" data-height="400"