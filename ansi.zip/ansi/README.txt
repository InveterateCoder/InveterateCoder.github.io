ansi: ANSI encoded text editor
	Options:
		/set - Settings
		-r - Read Only Mode
		-c - Create New

bcp: Prints a known ansi page code // need to supply the number of a page